// Error handler placeholder
