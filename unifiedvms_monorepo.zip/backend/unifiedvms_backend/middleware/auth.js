// Auth middleware placeholder
