from flask import Blueprint, request, jsonify
from models.candidate import Candidate
from utils.database import db

candidate_bp = Blueprint('candidate_bp', __name__)

@candidate_bp.route('/', methods=['POST'])
def submit_candidate():
    data = request.get_json()
    candidate = Candidate(
        vendor_id=data['vendor_id'],
        job_order_id=data['job_order_id'],
        name=data['name'],
        email=data.get('email'),
        phone=data.get('phone'),
        status=data.get('status', 'submitted'),
        resume=data.get('resume')
    )
    db.session.add(candidate)
    db.session.commit()
    return jsonify({'message': 'Candidate submitted', 'id': candidate.id}), 201

@candidate_bp.route('/', methods=['GET'])
def list_candidates():
    candidates = Candidate.query.all()
    result = [{
        'id': c.id,
        'vendor_id': c.vendor_id,
        'job_order_id': c.job_order_id,
        'name': c.name,
        'email': c.email,
        'phone': c.phone,
        'status': c.status,
        'resume': c.resume
    } for c in candidates]
    return jsonify(result)