from flask import Blueprint, request, jsonify
from models.document import Document
from utils.database import db

document_bp = Blueprint('document_bp', __name__)

@document_bp.route('/', methods=['POST'])
def upload_document():
    data = request.get_json()
    doc = Document(
        vendor_id=data['vendor_id'],
        type=data['type'],
        status=data.get('status', 'valid'),
        expiry_date=data['expiry_date']
    )
    db.session.add(doc)
    db.session.commit()
    return jsonify({'message': 'Document uploaded', 'id': doc.id}), 201

@document_bp.route('/', methods=['GET'])
def list_documents():
    docs = Document.query.all()
    result = [{
        'id': d.id,
        'vendor_id': d.vendor_id,
        'type': d.type,
        'status': d.status,
        'expiry_date': d.expiry_date
    } for d in docs]
    return jsonify(result)