from flask import Blueprint, request, jsonify
from models.invoice import Invoice
from utils.database import db

invoice_bp = Blueprint('invoice_bp', __name__)

@invoice_bp.route('/', methods=['POST'])
def create_invoice():
    data = request.get_json()
    inv = Invoice(
        vendor_id=data['vendor_id'],
        amount=data['amount'],
        date=data['date'],
        status=data.get('status', 'unpaid')
    )
    db.session.add(inv)
    db.session.commit()
    return jsonify({'message': 'Invoice created', 'id': inv.id}), 201

@invoice_bp.route('/', methods=['GET'])
def list_invoices():
    invoices = Invoice.query.all()
    result = [{
        'id': i.id,
        'vendor_id': i.vendor_id,
        'amount': i.amount,
        'date': i.date,
        'status': i.status
    } for i in invoices]
    return jsonify(result)