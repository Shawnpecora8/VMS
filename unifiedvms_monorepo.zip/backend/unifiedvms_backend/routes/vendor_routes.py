from flask import Blueprint, request, jsonify
from models.vendor import Vendor
from utils.database import db

vendor_bp = Blueprint('vendor_bp', __name__)

@vendor_bp.route('/', methods=['POST'])
def create_vendor():
    data = request.get_json()
    vendor = Vendor(
        company_id=data['company_id'],
        name=data['name'],
        status=data.get('status', 'active'),
        contact_name=data.get('contact_name'),
        email=data.get('email')
    )
    db.session.add(vendor)
    db.session.commit()
    return jsonify({'message': 'Vendor created', 'id': vendor.id}), 201

@vendor_bp.route('/', methods=['GET'])
def list_vendors():
    vendors = Vendor.query.all()
    result = [{
        'id': v.id,
        'company_id': v.company_id,
        'name': v.name,
        'status': v.status,
        'contact_name': v.contact_name,
        'email': v.email
    } for v in vendors]
    return jsonify(result)