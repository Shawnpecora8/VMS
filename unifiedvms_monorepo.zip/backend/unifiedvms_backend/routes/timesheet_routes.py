from flask import Blueprint, request, jsonify
from models.timesheet import Timesheet
from utils.database import db

timesheet_bp = Blueprint('timesheet_bp', __name__)

@timesheet_bp.route('/', methods=['POST'])
def submit_timesheet():
    data = request.get_json()
    t = Timesheet(
        worker_id=data['worker_id'],
        hours=data['hours'],
        week_start=data['week_start'],
        status=data.get('status', 'pending')
    )
    db.session.add(t)
    db.session.commit()
    return jsonify({'message': 'Timesheet submitted', 'id': t.id}), 201

@timesheet_bp.route('/', methods=['GET'])
def list_timesheets():
    timesheets = Timesheet.query.all()
    result = [{
        'id': t.id,
        'worker_id': t.worker_id,
        'hours': t.hours,
        'week_start': t.week_start,
        'status': t.status
    } for t in timesheets]
    return jsonify(result)