from flask import Blueprint, request, jsonify
from models.company import Company
from utils.database import db

company_bp = Blueprint('company_bp', __name__)

@company_bp.route('/', methods=['POST'])
def create_company():
    data = request.get_json()
    company = Company(
        name=data['name'],
        address=data.get('address'),
        industry=data.get('industry')
    )
    db.session.add(company)
    db.session.commit()
    return jsonify({'message': 'Company created', 'id': company.id}), 201