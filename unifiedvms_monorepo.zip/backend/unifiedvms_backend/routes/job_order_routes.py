from flask import Blueprint, request, jsonify
from models.job_order import JobOrder
from utils.database import db

job_order_bp = Blueprint('job_order_bp', __name__)

@job_order_bp.route('/', methods=['POST'])
def create_job_order():
    data = request.get_json()
    job = JobOrder(
        company_id=data['company_id'],
        title=data['title'],
        location=data.get('location'),
        status=data.get('status', 'open'),
        openings=data.get('openings', 1)
    )
    db.session.add(job)
    db.session.commit()
    return jsonify({'message': 'Job order created', 'id': job.id}), 201

@job_order_bp.route('/', methods=['GET'])
def list_job_orders():
    jobs = JobOrder.query.all()
    result = [{
        'id': job.id,
        'title': job.title,
        'location': job.location,
        'status': job.status,
        'openings': job.openings
    } for job in jobs]
    return jsonify(result)