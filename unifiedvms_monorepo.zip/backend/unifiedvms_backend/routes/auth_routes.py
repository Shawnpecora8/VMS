from flask import Blueprint, request, jsonify
from models.user import User
from utils.database import db

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    user = User(
        name=data['name'],
        email=data['email'],
        role=data.get('role', 'admin'),
        company_id=data.get('company_id')
    )
    user.set_password(data['password'])
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered', 'id': user.id}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()
    if user and user.check_password(data['password']):
        return jsonify({'message': 'Login successful', 'user_id': user.id, 'role': user.role})
    return jsonify({'message': 'Invalid credentials'}), 401