class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///unifiedvms.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'super-secret-key'