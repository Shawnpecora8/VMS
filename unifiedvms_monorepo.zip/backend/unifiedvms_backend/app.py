from flask import Flask
from flask_cors import CORS
from utils.database import db, init_db
from routes.auth_routes import auth_bp
from routes.company_routes import company_bp
from routes.job_order_routes import job_order_bp

app = Flask(__name__)
app.config.from_object('config.Config')
CORS(app)

init_db(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(company_bp, url_prefix='/api/companies')
app.register_blueprint(job_order_bp, url_prefix='/api/jobs')

if __name__ == '__main__':
    app.run(debug=True)