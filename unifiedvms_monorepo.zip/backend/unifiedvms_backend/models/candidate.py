from utils.database import db

class Candidate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendor.id'))
    job_order_id = db.Column(db.Integer, db.ForeignKey('job_order.id'))
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    status = db.Column(db.String(50), default='submitted')  # submitted, interviewed, hired
    resume = db.Column(db.String(200))  # link to file