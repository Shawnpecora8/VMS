from utils.database import db

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vendor_id = db.Column(db.Integer)
    amount = db.Column(db.Float)
    date = db.Column(db.String(20))
    status = db.Column(db.String(50), default='unpaid')  # unpaid, paid, overdue