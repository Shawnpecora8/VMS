from utils.database import db

class JobOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(150))
    status = db.Column(db.String(50), default='open')  # open, filled, closed
    openings = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, server_default=db.func.now())