from utils.database import db

class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(200))
    industry = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, server_default=db.func.now())