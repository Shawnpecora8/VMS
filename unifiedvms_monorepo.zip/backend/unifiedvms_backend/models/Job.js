// Job model schema placeholder
