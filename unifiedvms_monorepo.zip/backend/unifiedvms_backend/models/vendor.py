from utils.database import db

class Vendor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'))
    name = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(50), default='active')  # active/inactive
    contact_name = db.Column(db.String(100))
    email = db.Column(db.String(100))