from utils.database import db

class Timesheet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    worker_id = db.Column(db.Integer)
    hours = db.Column(db.Float)
    week_start = db.Column(db.String(20))
    status = db.Column(db.String(50), default='pending')  # pending, approved, rejected