from utils.database import db

class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vendor_id = db.Column(db.Integer)
    type = db.Column(db.String(100))
    status = db.Column(db.String(50))  # valid, expired
    expiry_date = db.Column(db.String(20))