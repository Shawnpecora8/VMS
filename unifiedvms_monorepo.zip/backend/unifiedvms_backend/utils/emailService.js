// Email service utility placeholder
