// Logger utility placeholder
