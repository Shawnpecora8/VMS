# UnifiedVMS (Monorepo)

This project contains both the backend (Flask) and frontend (React) for the UnifiedVMS platform.

## Structure

- `/backend/unifiedvms_backend`: Flask API
- `/frontend/unifiedvms_frontend`: React client

## Deployment

This repo uses Render.com to deploy both services under a single environment.