import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api', // Update this for production
});

export const login = (credentials) => API.post('/auth/login', credentials);
export const signup = (data) => API.post('/auth/signup', data);