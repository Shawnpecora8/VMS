import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>Welcome to UnifiedVMS Dashboard</h2>
      <p>Select a module from the sidebar.</p>
    </div>
  );
}

export default Dashboard;